module com.example.javafxassign3 {
    requires javafx.controls;
    requires javafx.fxml;
    requires org.json;


    opens com.example.javafxassign3 to javafx.fxml;
    exports com.example.javafxassign3;
}