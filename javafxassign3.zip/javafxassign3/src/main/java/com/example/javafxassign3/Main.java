// Importing necessary JavaFX and JSON libraries
package com.example.javafxassign3;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.TextAlignment;
import javafx.stage.Modality;
import javafx.stage.Stage;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class Main extends Application {

    // Declaring necessary UI components and variables
    private ListView<String> resultList;
    private final String apiKey = "5O93NAWUbBhmjqLmEIirRStVUGW6V9m5hIVJtGv6";
    private JSONArray jsonArray;

    @Override
    public void start(Stage primaryStage) {
        // Initializing UI components
        TextField makeField = new TextField();
        TextField modelField = new TextField();
        Button searchButton = new Button("Search");
        resultList = new ListView<>();

        // Styling UI components
        makeField.setStyle("-fx-background-color: white; -fx-border-color: #FFC300; -fx-border-width: 2px; -fx-padding: 8px; -fx-pref-width: 50%; -fx-pref-height: 40px; -fx-border-color: black; ");
        modelField.setStyle("-fx-background-color: white; -fx-border-color: #FFC300; -fx-border-width: 2px; -fx-padding: 8px; -fx-pref-width: 50%; -fx-pref-height: 40px; -fx-border-color: black; ");
        searchButton.setStyle("-fx-background-color: blue; -fx-font-size: 14; -fx-text-fill: #FFFFFF; -fx-font-weight: bold; -fx-padding: 12px 16px; -fx-min-width: 120px; -fx-border-color: black;");

        resultList.setPrefWidth(200);

        // Event handling for search button
        searchButton.setOnAction(event -> {
            String make = makeField.getText().trim();
            String model = modelField.getText().trim();
            if (!make.isEmpty() || !model.isEmpty()) {
                try {
                    // Fetching data from API
                    String apiUrl = "https://api.api-ninjas.com/v1/motorcycles?make=" + URLEncoder.encode(make, "UTF-8") +
                            "&model=" + URLEncoder.encode(model, "UTF-8");

                    URL url = new URL(apiUrl);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setRequestProperty("X-Api-Key", apiKey);

                    BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String inputLine;
                    while ((inputLine = in.readLine()) != null) {
                        response.append(inputLine);
                    }
                    in.close();

                    jsonArray = new JSONArray(response.toString());

                    // Displaying search results
                    resultList.getItems().clear();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject motorcycle = jsonArray.getJSONObject(i);
                        resultList.getItems().add(motorcycle.getString("make") + " " + motorcycle.getString("model"));
                    }
                    resultList.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        // Event handling for selecting a result
        resultList.setOnMouseClicked(event -> {
            String selectedMotorcycle = resultList.getSelectionModel().getSelectedItem();
            if (selectedMotorcycle != null) {
                try {
                    for (int i = 0; i < resultList.getItems().size(); i++) {
                        String makeModel = resultList.getItems().get(i);
                        if (makeModel.equals(selectedMotorcycle)) {
                            JSONObject motorcycle = jsonArray.getJSONObject(i);
                            displayMotorcycleDetails(motorcycle);
                            break;
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        // Creating the search UI layout
        VBox searchBox = new VBox(5, new Label("Make"), makeField, new Label("Model"), modelField, searchButton, resultList);
        searchBox.setStyle("-fx-background-color: beige;");
        VBox.setMargin(searchBox, new Insets(10));

        // Creating the main UI layout
        VBox root = new VBox(10);
        Label titleLabel = new Label("BIKE GRAM");
        titleLabel.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        titleLabel.setTextAlignment(TextAlignment.CENTER);
        titleLabel.setPadding(new Insets(0, 0, 10, 0));
        root.getChildren().addAll(titleLabel, searchBox);
        root.setBackground(new Background(new BackgroundFill(Color.LIGHTYELLOW, CornerRadii.EMPTY, Insets.EMPTY)));
        searchButton.setDefaultButton(true);
        resultList.setVisible(false);
        root.setPadding(new Insets(10));

        // Setting up the primary stage
        primaryStage.setScene(new Scene(root, 800, 600));
        primaryStage.setTitle("Motorcycle Search App");
        primaryStage.show();
    }

    // Method to display motorcycle details in a separate stage
    private void displayMotorcycleDetails(JSONObject motorcycle) {
        Stage detailsStage = new Stage();
        detailsStage.setTitle("Motorcycle Details");

        VBox detailsBox = new VBox(10);
        detailsBox.setPadding(new Insets(10));

        // Adding motorcycle details to the details box
        detailsBox.getChildren().addAll(
                new Label("Make: " + motorcycle.getString("make")),
                new Label("Model: " + motorcycle.getString("model")),
                new Label("Year: " + motorcycle.getString("year")),
                new Label("Engine: " + motorcycle.getString("engine"))
        );

        Scene scene = new Scene(detailsBox, 400, 300);
        detailsStage.setScene(scene);

        // Styling details box
        detailsBox.setBackground(new Background(new BackgroundFill(Color.LIGHTYELLOW, CornerRadii.EMPTY, Insets.EMPTY)));

        // Making the details stage modal
        detailsStage.initModality(Modality.APPLICATION_MODAL);
        detailsStage.show();
    }

    // Main method to launch the application
    public static void main(String[] args) {
        launch(args);
    }
}
